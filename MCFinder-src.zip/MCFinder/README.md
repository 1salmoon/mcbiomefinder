# MCFinder

Mod LeviLauncher untuk mencari fungsi warna rumput/daun (dan fungsi lain) di `libminecraftpe.so`.

## Pakai
1. Build (`xmake f -y -p android -a arm64-v8a -m release --ndk=<ndk>` lalu `xmake -y`) atau pakai GitHub Actions.
2. Impor `MCFinder.levipack` di LeviLauncher, aktifkan, jalankan Minecraft.
3. Tunggu ±2 menit setelah game terbuka. Laporan ditulis ke salah satu dari:
   - folder config mod (`.../finder_report.txt`)
   - `/sdcard/games/MCFinder/finder_report.txt`
   - `/sdcard/Download/MCFinder_report.txt`
4. Kirim isi `finder_report.txt` ke Claude untuk dibuatkan hook warna musim.

Laporan dibuat sekali. Hapus file itu kalau mau scan ulang (mis. setelah update Minecraft).

## Isi laporan
Info modul + fingerprint versi, string terkait warna, kandidat fungsi yang mereferensikannya
(diurutkan: yang memuat banyak kata kunci seperti grass + foliage di atas) beserta signature
terverifikasi unik, dan slot vtable `Biome`/`GrassBlock`/`LeafBlock` via RTTI.

Catatan: string pendek yang dibangun lewat instruksi MOV tidak terdeteksi; kandidat tetap perlu diverifikasi manual.
