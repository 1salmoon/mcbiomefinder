// MCFinder - LeviLauncher mod that scans libminecraftpe.so at runtime and writes a
// report with function candidates + ready-to-use signatures (grass/foliage colour focus).
#include "scanner.hpp"

#include <android/log.h>
#include <pl/Mod.hpp>

#include <sys/stat.h>
#include <dlfcn.h>
#include <unistd.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <map>
#include <set>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

namespace fs = std::filesystem;
using namespace mcfinder;

namespace {

constexpr const char* kLibrary = "libminecraftpe.so";
constexpr const char* kTag = "MCFinder";
constexpr auto kPatternBudget = std::chrono::seconds(90);

void logi(const std::string& message) { __android_log_print(ANDROID_LOG_INFO, kTag, "%s", message.c_str()); }

struct Module {
    std::string path;
    std::uintptr_t base = 0;
    std::vector<Region> regions;
};

bool readModule(Module& module) {
    std::ifstream maps("/proc/self/maps");
    if (!maps) return false;
    std::string line;
    std::uintptr_t lowest = ~std::uintptr_t(0);
    while (std::getline(maps, line)) {
        if (line.find(kLibrary) == std::string::npos) continue;
        unsigned long long start = 0, end = 0, offset = 0;
        char perms[8] = {};
        if (std::sscanf(line.c_str(), "%llx-%llx %7s %llx", &start, &end, perms, &offset) != 4) continue;
        lowest = std::min<std::uintptr_t>(lowest, static_cast<std::uintptr_t>(start));
        if (perms[0] != 'r') continue;
        const bool exec = perms[2] == 'x';
        if (!exec && perms[1] == 'w') continue;  // skip .data/.bss, keep rodata
        module.regions.push_back({static_cast<std::uintptr_t>(start), static_cast<std::size_t>(end - start),
                                  reinterpret_cast<const std::uint8_t*>(start), exec});
        const auto slash = line.find('/');
        if (slash != std::string::npos && module.path.empty()) module.path = line.substr(slash);
    }
    module.base = lowest == ~std::uintptr_t(0) ? 0 : lowest;
    return !module.regions.empty();
}

std::string hex(std::uint64_t v) {
    char buf[32];
    std::snprintf(buf, sizeof(buf), "0x%llX", static_cast<unsigned long long>(v));
    return buf;
}

std::uint64_t fingerprint(const Module& module) {
    std::uint64_t h = 1469598103934665603ull;
    for (const auto& r : module.regions) {
        if (!r.exec) continue;
        const std::size_t n = std::min<std::size_t>(r.size, 256 * 1024);
        for (std::size_t i = 0; i < n; ++i) { h ^= r.data[i]; h *= 1099511628211ull; }
        break;
    }
    return h;
}

struct Budget {
    std::chrono::steady_clock::time_point deadline;
    static bool expired(void* self) { return std::chrono::steady_clock::now() > static_cast<Budget*>(self)->deadline; }
};

std::string buildReport(const Module& module) {
    std::ostringstream out;
    struct stat st{};
    const long long fileSize = !module.path.empty() && stat(module.path.c_str(), &st) == 0 ? st.st_size : -1;

    out << "=== MCFinder report ===\n";
    out << "module: " << module.path << "\n";
    out << "file size: " << fileSize << "\n";
    out << "base: " << hex(module.base) << "\n";
    out << "text fingerprint: " << hex(fingerprint(module)) << "\n";
    out << "regions:\n";
    for (const auto& r : module.regions)
        out << "  " << (r.exec ? "x" : "r") << " +" << hex(r.base - module.base) << " size " << hex(r.size) << "\n";

    const std::vector<std::string> keywords = {
        "textures/colormap/grass", "textures/colormap/foliage", "Failed to load grass resource",
        "Failed to load foliage resource", "Failed to set palette for", "TessellationPolicy",
        "foliage_altitude_factor", "default_foliage", "swamp_grass", "evergreen_foliage", "birch_foliage",
        "grass_color", "foliage_color", "water_color", "color_grass", "color_foliage",
        "grass_map", "foliage_map", "BiomeColor", "biome_color", "evergreen", "birch",
        "tallgrass", "leaves", "foliage", "tint", "grass"};

    auto strings = findStrings(module.regions, keywords, 24);
    out << "\n== strings found: " << strings.size() << " ==\n";
    for (const auto& s : strings)
        out << "[" << s.keyword << "] +" << hex(s.addr - module.base) << " \"" << s.text << "\"\n";

    XrefStats stats;
    auto xrefs = findXrefs(module.regions, strings, 8, &stats);
    out << "\nxref stats: adrp=" << stats.adrpTotal << " pageHit=" << stats.adrpPageHit
        << " noMatchingAdd=" << stats.addMismatch << " xrefs=" << xrefs.size() << "\n";
    for (std::size_t i = 0; i < strings.size(); ++i) {
        const auto refs = findPointerSlots(module.regions, strings[i].addr, 2);
        for (const auto slot : refs)
            out << "data ref: \"" << strings[i].text << "\" held at +" << hex(slot - module.base) << "\n";
    }
    struct FuncInfo {
        std::set<std::string> keywords;
        std::vector<std::string> notes;
    };
    std::map<std::uintptr_t, FuncInfo> funcs;
    std::size_t noFunction = 0;
    for (const auto& x : xrefs) {
        const auto start = findFunctionStart(module.regions, x.pc);
        if (!start) { ++noFunction; continue; }
        auto& info = funcs[start];
        info.keywords.insert(strings[x.stringIndex].keyword);
        info.notes.push_back("\"" + strings[x.stringIndex].text + "\" referenced at +" + hex(x.pc - module.base) +
                             " (function +" + hex(x.pc - start) + ")");
    }

    std::vector<std::pair<std::uintptr_t, const FuncInfo*>> ranked;
    for (const auto& [addr, info] : funcs) ranked.emplace_back(addr, &info);
    std::sort(ranked.begin(), ranked.end(), [](const auto& a, const auto& b) {
        if (a.second->keywords.size() != b.second->keywords.size())
            return a.second->keywords.size() > b.second->keywords.size();
        return a.second->notes.size() > b.second->notes.size();
    });

    out << "\n== function candidates: " << ranked.size() << " (xrefs without function start: " << noFunction << ") ==\n";
    Budget budget{std::chrono::steady_clock::now() + kPatternBudget};
    std::size_t index = 0;
    for (const auto& [addr, info] : ranked) {
        if (index++ >= 80) break;
        out << "\n#" << index << " function +" << hex(addr - module.base) << "  keywords:";
        for (const auto& k : info->keywords) out << " " << k;
        out << "\n";
        for (std::size_t i = 0; i < info->notes.size() && i < 6; ++i) out << "  - " << info->notes[i] << "\n";
        const auto pattern = uniquePattern(module.regions, addr, 32, 128, Budget::expired, &budget);
        out << "  signature (" << pattern.bytes << " bytes, matches=" << pattern.count << ", "
            << (pattern.verified ? "verified" : "UNVERIFIED") << "):\n  " << pattern.pattern << "\n";
    }

    out << "\n== vtables via RTTI name ==\n";
    const char* rttiNames[] = {
        "N18BiomeColorSampling23GrassTessellationPolicyE", "N18BiomeColorSampling25FoliageTessellationPolicyE",
        "N18BiomeColorSampling23WaterTessellationPolicyE", "N18BiomeColorSampling24BiomeAndPatternMapPolicyE",
        "N18BiomeColorSampling18TessellationPolicyE", "5Biome", "10GrassBlock", "9LeafBlock", "10LeavesBlock",
        "11BlockLegacy", "14BiomeRegistry"};
    for (const char* rtti : rttiNames) {
        const auto vt = vtableFromTypeName(module.regions, rtti);
        if (!vt) { out << "[" << rtti << "] not found\n"; continue; }
        out << "[" << rtti << "] vtable +" << hex(vt - module.base) << "\n";
        for (std::size_t slot = 0; slot < 24; ++slot) {
            std::uint8_t ptr[8];
            if (!readBytes(module.regions, vt + slot * 8, ptr, 8)) break;
            std::uint64_t address;
            std::memcpy(&address, ptr, 8);
            std::uint8_t code[48];
            if (!readBytes(module.regions, address, code, sizeof(code))) break;
            out << "  slot " << slot << " +" << hex(address - module.base) << "  " << makePattern(code, sizeof(code)) << "\n";
        }
    }

    out << "\n=== end of report ===\n";
    return out.str();
}

bool writeFile(const fs::path& path, const std::string& text) {
    std::error_code ec;
    fs::create_directories(path.parent_path(), ec);
    std::ofstream file(path, std::ios::binary | std::ios::trunc);
    if (!file) return false;
    file << text;
    return static_cast<bool>(file);
}

class Finder {
public:
    static Finder& get() {
        static Finder instance;
        return instance;
    }

    bool load(pl::mod::ModContext& context) {
        mConfigDir = context.configDir();
        return true;
    }

    bool enable(pl::mod::ModContext&) {
        if (mStarted.exchange(true)) return true;
        mStop = false;
        std::thread([this] { run(); }).detach();
        return true;
    }

    bool disable(pl::mod::ModContext&) {
        mStop = true;
        return true;
    }

    bool unload(pl::mod::ModContext&) {
        mStop = true;
        return true;
    }

private:
    void run() {
        const fs::path primary = mConfigDir / "finder_report.txt";
        std::error_code ec;
        if (fs::exists(primary, ec)) {
            logi("report already exists, delete it to scan again: " + primary.string());
            return;
        }
        for (int i = 0; i < 600 && !mStop; ++i) {
            void* handle = dlopen(kLibrary, RTLD_NOW | RTLD_NOLOAD);
            if (handle) { dlclose(handle); break; }
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
        if (mStop) return;
        std::this_thread::sleep_for(std::chrono::seconds(10));  // let the game finish mapping

        Module module;
        if (!readModule(module)) {
            logi("could not read mappings of libminecraftpe.so");
            return;
        }
        logi("scanning, this takes up to ~2 minutes");
        const std::string report = buildReport(module);

        const fs::path targets[] = {primary, "/sdcard/games/MCFinder/finder_report.txt",
                                    "/sdcard/Download/MCFinder_report.txt"};
        for (const auto& target : targets)
            logi(std::string(writeFile(target, report) ? "report written: " : "cannot write: ") + target.string());
    }

    fs::path mConfigDir;
    std::atomic_bool mStarted{false};
    std::atomic_bool mStop{false};
};

}  // namespace

class MCFinderMod {
public:
    static MCFinderMod& instance() {
        static MCFinderMod mod;
        return mod;
    }
    bool load(pl::mod::ModContext& c) { return Finder::get().load(c); }
    bool enable(pl::mod::ModContext& c) { return Finder::get().enable(c); }
    bool disable(pl::mod::ModContext& c) { return Finder::get().disable(c); }
    bool unload(pl::mod::ModContext& c) { return Finder::get().unload(c); }
};

PL_REGISTER_MOD(MCFinderMod, MCFinderMod::instance())
