#include "scanner.hpp"

#include <algorithm>
#include <cstdio>
#include <cstring>
#include <string_view>
#include <unordered_map>
#include <unordered_set>

namespace mcfinder {
namespace {

std::uint32_t word(const std::uint8_t* p) {
    std::uint32_t v;
    std::memcpy(&v, p, 4);
    return v;
}

bool printable(std::uint8_t c) { return c >= 0x20 && c < 0x7F; }

const Region* regionFor(const std::vector<Region>& regions, std::uintptr_t addr) {
    for (const auto& r : regions)
        if (addr >= r.base && addr < r.base + r.size) return &r;
    return nullptr;
}

bool isTerminator(std::uint32_t w) {
    return w == 0xD65F03C0u                          // RET
        || (w & 0xFC000000u) == 0x14000000u          // B
        || (w & 0xFFFFFC1Fu) == 0xD61F0000u          // BR
        || (w & 0xFFE0001Fu) == 0xD4200000u          // BRK
        || w == 0;                                   // padding
}

bool isPrologue(std::uint32_t w) {
    if ((w & 0xFF0003FFu) == 0xD10003FFu) return true;                       // SUB sp, sp, #imm
    if (w == 0xD503233Fu) return true;                                       // PACIASP
    if (w == 0xF81F0FFEu) return true;                                       // STR x30, [sp, #-16]!
    const bool spBase = ((w >> 5) & 31) == 31;
    if (spBase && (w & 0xFFC00000u) == 0xA9800000u) return true;             // STP pre-index
    if (spBase && (w & 0xFFC00000u) == 0x6D800000u) return true;             // STP d-regs pre-index
    if (spBase && (w & 0xFFC00000u) == 0xA9000000u) return true;             // STP signed offset
    return false;
}

// Wildcard rule follows the style already used by LeviLauncher mods:
// keep the opcode byte, drop operands that change between builds.
bool wildcardsLow3(std::uint32_t w) {
    if ((w & 0x9F000000u) == 0x90000000u) return true;   // ADRP
    if ((w & 0x9F000000u) == 0x10000000u) return true;   // ADR
    if ((w & 0x7C000000u) == 0x14000000u) return true;   // B / BL
    if ((w & 0xFF000010u) == 0x54000000u) return true;   // B.cond
    if ((w & 0x7E000000u) == 0x34000000u) return true;   // CBZ / CBNZ
    if ((w & 0x7E000000u) == 0x36000000u) return true;   // TBZ / TBNZ
    if ((w & 0x3B000000u) == 0x18000000u) return true;   // LDR literal
    if ((w & 0x3B000000u) == 0x39000000u) return true;   // LDR/STR unsigned offset
    if ((w & 0x3A000000u) == 0x28000000u) return true;   // LDP/STP
    if ((w & 0x1F800000u) == 0x12800000u) return true;   // MOVN/MOVZ/MOVK
    if ((w & 0x7F000000u) == 0x11000000u || (w & 0x7F000000u) == 0x51000000u)  // ADD/SUB imm
        return ((w >> 10) & 0xFFF) != 0;
    return false;
}

struct Parsed {
    std::vector<int> bytes;  // -1 = wildcard
};

bool parsePattern(const std::string& text, Parsed& out) {
    out.bytes.clear();
    std::size_t i = 0;
    while (i < text.size()) {
        if (text[i] == ' ') { ++i; continue; }
        if (text[i] == '?') { out.bytes.push_back(-1); ++i; continue; }
        if (i + 1 >= text.size()) return false;
        unsigned v = 0;
        if (std::sscanf(text.c_str() + i, "%2x", &v) != 1) return false;
        out.bytes.push_back(static_cast<int>(v));
        i += 2;
    }
    return !out.bytes.empty();
}

std::size_t countParsed(const std::vector<Region>& regions, const Parsed& p, std::size_t limit) {
    std::size_t found = 0;
    const std::size_t n = p.bytes.size();
    for (const auto& r : regions) {
        if (!r.exec || r.size < n) continue;
        for (std::size_t off = 0; off + n <= r.size; off += 4) {
            const std::uint8_t* d = r.data + off;
            std::size_t k = 0;
            for (; k < n; ++k)
                if (p.bytes[k] >= 0 && d[k] != p.bytes[k]) break;
            if (k == n && ++found >= limit) return found;
        }
    }
    return found;
}

}  // namespace

std::vector<StringHit> findStrings(const std::vector<Region>& regions,
                                   const std::vector<std::string>& keywords,
                                   std::size_t perKeywordCap) {
    std::vector<StringHit> hits;
    std::unordered_set<std::uintptr_t> seen;
    for (const auto& kw : keywords) {
        std::size_t taken = 0;
        for (const auto& r : regions) {
            if (r.exec || taken >= perKeywordCap) continue;
            std::string_view hay(reinterpret_cast<const char*>(r.data), r.size);
            std::size_t pos = 0;
            while (taken < perKeywordCap && (pos = hay.find(kw, pos)) != std::string_view::npos) {
                std::size_t start = pos;
                std::size_t back = 0;
                while (start > 0 && printable(r.data[start - 1]) && back < 160) { --start; ++back; }
                std::size_t end = pos + kw.size();
                while (end < r.size && printable(r.data[end]) && end - start < 200) ++end;
                const bool terminated = end < r.size && r.data[end] == 0;
                const bool startOk = start == 0 || r.data[start - 1] == 0;
                pos += kw.size();
                if (!terminated || !startOk || end - start > 120) continue;
                const std::uintptr_t addr = r.base + start;
                if (!seen.insert(addr).second) continue;
                hits.push_back({addr, std::string(hay.substr(start, end - start)), kw});
                ++taken;
            }
        }
    }
    return hits;
}

std::vector<XrefHit> findXrefs(const std::vector<Region>& regions,
                               const std::vector<StringHit>& strings,
                               std::size_t perStringCap, XrefStats* stats) {
    // Match a target that lands anywhere inside a string (tail-merged literals).
    std::vector<std::pair<std::uintptr_t, std::size_t>> ranges;  // start -> index
    std::unordered_set<std::uintptr_t> pages;
    for (std::size_t i = 0; i < strings.size(); ++i) {
        ranges.emplace_back(strings[i].addr, i);
        const std::uintptr_t end = strings[i].addr + strings[i].text.size();
        for (std::uintptr_t p = strings[i].addr & ~std::uintptr_t(0xFFF); p <= end; p += 0x1000) pages.insert(p);
    }
    std::sort(ranges.begin(), ranges.end());
    auto lookup = [&](std::uintptr_t target) -> long {
        auto it = std::upper_bound(ranges.begin(), ranges.end(), std::make_pair(target, ~std::size_t(0)));
        if (it == ranges.begin()) return -1;
        --it;
        const auto& s = strings[it->second];
        return target < s.addr + s.text.size() + 1 ? static_cast<long>(it->second) : -1;
    };
    std::vector<std::size_t> counts(strings.size(), 0);
    std::vector<XrefHit> out;
    for (const auto& r : regions) {
        if (!r.exec) continue;
        const std::size_t words = r.size / 4;
        for (std::size_t i = 0; i < words; ++i) {
            const std::uint32_t w = word(r.data + i * 4);
            if ((w & 0x9F000000u) != 0x90000000u) continue;  // ADRP
            if (stats) ++stats->adrpTotal;
            const std::uintptr_t pc = r.base + i * 4;
            std::int64_t imm = static_cast<std::int64_t>((((w >> 5) & 0x7FFFF) << 2) | ((w >> 29) & 3));
            if (imm & (1 << 20)) imm -= (1 << 21);
            const std::uintptr_t page = (pc & ~std::uintptr_t(0xFFF)) + static_cast<std::uintptr_t>(imm * 4096);
            if (!pages.count(page)) continue;
            if (stats) ++stats->adrpPageHit;
            const unsigned rd = w & 31;
            bool matched = false;
            for (std::size_t j = 1; j <= 24 && i + j < words && !matched; ++j) {
                const std::uint32_t n = word(r.data + (i + j) * 4);
                if (((n >> 5) & 31) != rd) continue;
                std::uintptr_t target = 0;
                if ((n & 0xFF800000u) == 0x91000000u) target = page + ((n >> 10) & 0xFFF);          // ADD, no shift
                else if ((n & 0xFFC00000u) == 0x39400000u) target = page + ((n >> 10) & 0xFFF);     // LDRB
                else continue;
                const long idx = lookup(target);
                if (idx < 0 || counts[idx] >= perStringCap) continue;
                ++counts[idx];
                out.push_back({static_cast<std::size_t>(idx), pc});
                matched = true;
            }
            if (!matched && stats) ++stats->addMismatch;
        }
    }
    return out;
}

std::vector<std::size_t> adrpHistogram(const std::vector<Region>& regions) {
    std::vector<std::size_t> counts(regions.size(), 0);
    std::vector<std::size_t> order(regions.size());
    for (std::size_t i = 0; i < order.size(); ++i) order[i] = i;
    std::sort(order.begin(), order.end(), [&](auto a, auto b) { return regions[a].base < regions[b].base; });
    for (const auto& r : regions) {
        if (!r.exec) continue;
        const std::size_t words = r.size / 4;
        for (std::size_t i = 0; i < words; ++i) {
            const std::uint32_t w = word(r.data + i * 4);
            if ((w & 0x9F000000u) != 0x90000000u) continue;
            const std::uintptr_t pc = r.base + i * 4;
            std::int64_t imm = static_cast<std::int64_t>((((w >> 5) & 0x7FFFF) << 2) | ((w >> 29) & 3));
            if (imm & (1 << 20)) imm -= (1 << 21);
            const std::uintptr_t page = (pc & ~std::uintptr_t(0xFFF)) + static_cast<std::uintptr_t>(imm * 4096);
            std::size_t lo = 0, hi = order.size();
            while (lo < hi) {
                const std::size_t mid = (lo + hi) / 2;
                if (regions[order[mid]].base + regions[order[mid]].size <= page) lo = mid + 1; else hi = mid;
            }
            if (lo < order.size() && page >= regions[order[lo]].base) ++counts[order[lo]];
        }
    }
    return counts;
}

std::vector<std::uintptr_t> findPointerSlots(const std::vector<Region>& regions, std::uintptr_t value,
                                             std::size_t cap) {
    std::vector<std::uintptr_t> out;
    for (const auto& r : regions) {
        if (r.exec) continue;
        for (std::size_t off = 0; off + 8 <= r.size; off += 8) {
            std::uint64_t v;
            std::memcpy(&v, r.data + off, 8);
            if (v == value) {
                out.push_back(r.base + off);
                if (out.size() >= cap) return out;
            }
        }
    }
    return out;
}

std::uintptr_t findExactString(const std::vector<Region>& regions, const std::string& text) {
    const std::string needle = std::string(1, '\0') + text + std::string(1, '\0');
    for (const auto& r : regions) {
        if (r.exec) continue;
        std::string_view hay(reinterpret_cast<const char*>(r.data), r.size);
        const auto pos = hay.find(needle);
        if (pos != std::string_view::npos) return r.base + pos + 1;
    }
    return 0;
}

std::uintptr_t vtableFromTypeName(const std::vector<Region>& regions, const std::string& mangled) {
    const auto name = findExactString(regions, mangled);
    if (!name) return 0;
    for (const auto slot : findPointerSlots(regions, name, 4)) {   // typeinfo: [vptr, name]
        const std::uintptr_t typeinfo = slot - 8;
        for (const auto vslot : findPointerSlots(regions, typeinfo, 4))  // vtable[-1] = typeinfo
            return vslot + 8;
    }
    return 0;
}

std::uintptr_t findFunctionStart(const std::vector<Region>& regions, std::uintptr_t pc, std::size_t maxBack) {
    const Region* r = regionFor(regions, pc);
    if (!r || !r->exec) return 0;
    std::uintptr_t a = pc & ~std::uintptr_t(3);
    const std::uintptr_t limit = pc > r->base + maxBack ? pc - maxBack : r->base;
    for (;; a -= 4) {
        const std::uint32_t w = word(r->data + (a - r->base));
        if (isPrologue(w)) {
            if (a == r->base) return a;
            if (isTerminator(word(r->data + (a - r->base) - 4))) return a;
        }
        if (a <= limit || a <= r->base) break;
    }
    return 0;
}

bool readBytes(const std::vector<Region>& regions, std::uintptr_t addr, std::uint8_t* out, std::size_t n) {
    const Region* r = regionFor(regions, addr);
    if (!r || addr + n > r->base + r->size) return false;
    std::memcpy(out, r->data + (addr - r->base), n);
    return true;
}

std::string makePattern(const std::uint8_t* code, std::size_t bytes) {
    std::string out;
    char buf[4];
    for (std::size_t off = 0; off + 4 <= bytes; off += 4) {
        const std::uint32_t w = word(code + off);
        const bool wild = wildcardsLow3(w);
        for (int k = 0; k < 4; ++k) {
            if (!out.empty()) out += ' ';
            if (wild && k < 3) out += '?';
            else { std::snprintf(buf, sizeof(buf), "%02X", code[off + k]); out += buf; }
        }
    }
    return out;
}

std::size_t countPattern(const std::vector<Region>& regions, const std::string& pattern, std::size_t limit) {
    Parsed p;
    if (!parsePattern(pattern, p)) return 0;
    return countParsed(regions, p, limit);
}

PatternResult uniquePattern(const std::vector<Region>& regions, std::uintptr_t func,
                            std::size_t minBytes, std::size_t maxBytes,
                            bool (*expired)(void*), void* ctx) {
    PatternResult res;
    std::vector<std::uint8_t> code(maxBytes);
    std::size_t avail = maxBytes;
    while (avail >= 4 && !readBytes(regions, func, code.data(), avail)) avail -= 4;
    avail &= ~std::size_t(3);
    if (avail < 4) return res;
    minBytes = std::min(minBytes, avail);
    res.bytes = avail;
    res.pattern = makePattern(code.data(), avail);
    if (expired && expired(ctx)) return res;

    Parsed full;
    parsePattern(res.pattern, full);
    const std::size_t maxCount = countParsed(regions, full, 2);
    res.count = maxCount;
    res.verified = true;
    if (maxCount != 1) return res;

    std::size_t lo = minBytes / 4, hi = avail / 4;
    while (lo < hi) {
        if (expired && expired(ctx)) { res.verified = false; return res; }
        const std::size_t mid = (lo + hi) / 2;
        Parsed p;
        parsePattern(makePattern(code.data(), mid * 4), p);
        if (countParsed(regions, p, 2) == 1) hi = mid; else lo = mid + 1;
    }
    res.bytes = lo * 4;
    res.pattern = makePattern(code.data(), res.bytes);
    res.count = 1;
    return res;
}

}
