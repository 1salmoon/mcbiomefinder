#pragma once

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

// Pure, platform-independent AArch64 scanning helpers (unit-testable on a host).
namespace mcfinder {

struct Region {
    std::uintptr_t base;      // address the bytes live at in the target process
    std::size_t size;
    const std::uint8_t* data; // where we can read them from right now
    bool exec;
    bool writable = false;
    unsigned long long fileOffset = 0;
};

struct StringHit {
    std::uintptr_t addr;
    std::string text;
    std::string keyword;
};

struct XrefHit {
    std::size_t stringIndex;
    std::uintptr_t pc;
};

struct PatternResult {
    std::string pattern;   // "? ? ? D1 FD 03 00 91 ..."
    std::size_t bytes = 0;
    std::size_t count = 0;
    bool verified = false;
};

std::vector<StringHit> findStrings(const std::vector<Region>& regions,
                                   const std::vector<std::string>& keywords,
                                   std::size_t perKeywordCap);

struct XrefStats {
    std::size_t adrpTotal = 0;
    std::size_t adrpPageHit = 0;   // ADRP whose page contains a known string
    std::size_t addMismatch = 0;   // page hit but no ADD landed inside a string
};

std::vector<XrefHit> findXrefs(const std::vector<Region>& regions,
                               const std::vector<StringHit>& strings,
                               std::size_t perStringCap, XrefStats* stats = nullptr);

// For each region: how many ADRP instructions in executable regions point into it.
std::vector<std::size_t> adrpHistogram(const std::vector<Region>& regions);

// Every 8-byte aligned slot in readable non-exec memory that holds `value`.
std::vector<std::uintptr_t> findPointerSlots(const std::vector<Region>& regions, std::uintptr_t value,
                                             std::size_t cap = 8);

// Address of an exact NUL-delimited string (e.g. an Itanium typeinfo name), or 0.
std::uintptr_t findExactString(const std::vector<Region>& regions, const std::string& text);

// typeinfo-name string -> vtable start (address of slot 0), or 0.
std::uintptr_t vtableFromTypeName(const std::vector<Region>& regions, const std::string& mangled);

// Returns 0 when no plausible function start is found.
std::uintptr_t findFunctionStart(const std::vector<Region>& regions, std::uintptr_t pc,
                                 std::size_t maxBack = 0x8000);

std::string makePattern(const std::uint8_t* code, std::size_t bytes);
bool readBytes(const std::vector<Region>& regions, std::uintptr_t addr, std::uint8_t* out, std::size_t n);

std::size_t countPattern(const std::vector<Region>& regions, const std::string& pattern, std::size_t limit = 2);

// Shortest loose pattern (>= minBytes) that is unique in executable memory.
// If `budgetExpired` returns true the result is left unverified.
PatternResult uniquePattern(const std::vector<Region>& regions, std::uintptr_t func,
                            std::size_t minBytes, std::size_t maxBytes,
                            bool (*budgetExpired)(void*) = nullptr, void* ctx = nullptr);

}
