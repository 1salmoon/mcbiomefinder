#pragma once

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

// Pure, platform-independent AArch64 scanning helpers (unit-testable on a host).
namespace mcfinder {

struct Region {
    std::uintptr_t base;      // address the bytes live at in the target process
    std::size_t size;
    const std::uint8_t* data; // where we can read them from right now
    bool exec;
};

struct StringHit {
    std::uintptr_t addr;
    std::string text;
    std::string keyword;
};

struct XrefHit {
    std::size_t stringIndex;
    std::uintptr_t pc;
};

struct PatternResult {
    std::string pattern;   // "? ? ? D1 FD 03 00 91 ..."
    std::size_t bytes = 0;
    std::size_t count = 0;
    bool verified = false;
};

std::vector<StringHit> findStrings(const std::vector<Region>& regions,
                                   const std::vector<std::string>& keywords,
                                   std::size_t perKeywordCap);

std::vector<XrefHit> findXrefs(const std::vector<Region>& regions,
                               const std::vector<StringHit>& strings,
                               std::size_t perStringCap);

// Returns 0 when no plausible function start is found.
std::uintptr_t findFunctionStart(const std::vector<Region>& regions, std::uintptr_t pc,
                                 std::size_t maxBack = 0x8000);

std::string makePattern(const std::uint8_t* code, std::size_t bytes);
bool readBytes(const std::vector<Region>& regions, std::uintptr_t addr, std::uint8_t* out, std::size_t n);

std::size_t countPattern(const std::vector<Region>& regions, const std::string& pattern, std::size_t limit = 2);

// Shortest loose pattern (>= minBytes) that is unique in executable memory.
// If `budgetExpired` returns true the result is left unverified.
PatternResult uniquePattern(const std::vector<Region>& regions, std::uintptr_t func,
                            std::size_t minBytes, std::size_t maxBytes,
                            bool (*budgetExpired)(void*) = nullptr, void* ctx = nullptr);

}
