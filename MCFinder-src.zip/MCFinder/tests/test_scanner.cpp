#include "../src/scanner.hpp"
#include <cassert>
#include <cstdio>
#include <cstring>
#include <vector>
using namespace mcfinder;

static void put(std::vector<std::uint8_t>& v, std::size_t off, std::uint32_t w) { std::memcpy(v.data() + off, &w, 4); }

int main() {
    std::vector<std::uint8_t> ro(0x1000, 0), text(0x1000, 0);
    const char* s = "foliage_color";
    std::memcpy(ro.data() + 0x120, s, std::strlen(s) + 1);
    const std::uintptr_t roBase = 0x2000, txBase = 0x10000;

    put(text, 0x3C, 0xD65F03C0);                 // previous function ends with RET
    put(text, 0x40, 0xD10103FF);                 // sub sp, sp, #0x40
    put(text, 0x44, 0xA9037BFD);                 // stp x29, x30, [sp, #0x30]
    put(text, 0x48, 0x910C03FD);                 // add x29, sp, #0x300
    std::int64_t pages = (static_cast<std::int64_t>(roBase & ~0xFFFull) - static_cast<std::int64_t>((txBase + 0x4C) & ~0xFFFull)) >> 12;
    std::uint32_t immlo = pages & 3, immhi = (pages >> 2) & 0x7FFFF;
    put(text, 0x4C, 0x90000008u | (immlo << 29) | (immhi << 5));
    put(text, 0x50, 0x91000108u | (0x120u << 10));   // add x8, x8, #0x120
    put(text, 0x54, 0xD65F03C0);

    std::vector<Region> regions = {{roBase, ro.size(), ro.data(), false}, {txBase, text.size(), text.data(), true}};
    auto strings = findStrings(regions, {"foliage"}, 10);
    assert(strings.size() == 1 && strings[0].text == "foliage_color" && strings[0].addr == roBase + 0x120);
    auto xrefs = findXrefs(regions, strings, 5);
    assert(xrefs.size() == 1 && xrefs[0].pc == txBase + 0x4C);
    auto fn = findFunctionStart(regions, xrefs[0].pc);
    assert(fn == txBase + 0x40);
    auto pat = uniquePattern(regions, fn, 8, 24);
    std::printf("pattern: %s (bytes=%zu count=%zu verified=%d)\n", pat.pattern.c_str(), pat.bytes, pat.count, pat.verified);
    assert(pat.verified && pat.count == 1);
    assert(countPattern(regions, pat.pattern) == 1);
    std::puts("ok");
}
