# MotionLevi (v0.1.0, belum dites)

Mod native LeviLauncher yang menggantikan behavior pack EAF supaya **Motion+** jalan tanpa BP.
Dasar: fork trimmed dari BedrockTools (MIT, lihat LICENSE) — hanya core + modul `Motion Driver`.

## Cara kerja
EAF memanggil `player.playAnimation("animation.mbp_ap.player", {controller, stopExpression})` tiap tick.
Itu mengirim `AnimateEntityPacket` (id 0x9E). Mod ini membuat packet yang sama lokal lalu
menyuapkannya ke dispatcher client. Fase 1 hanya animasi utama (jalan/lari/idle/sneak/swim).
State `.true/.false` (makan, bow, sword, hurt, riding, dll) belum ada: fase 2.

## Kalibrasi (wajib sekali)
Layout packet, offset runtime id, dan MolangVersion tidak bisa diverifikasi tanpa binary,
jadi dipelajari dari packet asli EAF:
1. Build (GitHub Actions) -> `MotionLevi.levipack`, import di LeviLauncher.
2. Aktifkan **Motion+ dan EAF**, masuk world. Tunggu ~10 detik.
3. Cek `/sdcard/games/MotionLevi/motionlevi.log` dan `learned.json`.
   - `[learn] layout baru ... verified=1` = layout cocok.
   - `[learn] runtimeIdOffset = 0x...` = siap.
   - Kalau "ambigu" (id kecil seperti 1): kalibrasi di server/world dengan pemain lain, atau isi `runtimeIdOffset` manual di learned.json.
   - Kalau "tidak ada di objek Player": id disimpan di komponen ECS, kirim log ke Claude.
4. Matikan EAF, masuk world lagi. Log `[state] ... verified=1` lalu animasi jalan lewat mod.
Selama packet EAF masih masuk (2 detik terakhir), mod diam supaya tidak dobel.

## Kirim ke Claude kalau gagal
`motionlevi.log` + `learned.json`.

## Menuju standalone
Core sudah dipisah dari modul. Berikutnya: state animasi, pemain lain, bundel RP.
Kredit: EAF & Motion+ © ARGEE, BedrockTools © RadiantByte/MrPokeG (MIT).
