#pragma once

#include <cstdint>
#include <string_view>

namespace bedrocktools {

inline constexpr std::string_view Name = "MotionLevi";
inline constexpr std::string_view Author = "zey";
inline constexpr std::string_view Description = "Native driver for Motion+ third-person animations (EAF replacement, no behavior pack).";
inline constexpr std::string_view Version = "0.1.0";
inline constexpr std::uint32_t SdkVersion = 1;
inline constexpr std::string_view RuntimeLibrary = "libMotionLevi.so";

}
