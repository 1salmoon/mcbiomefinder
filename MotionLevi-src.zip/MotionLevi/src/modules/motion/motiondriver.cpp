#include "motiondriver.hpp"

#include "config/ConfigManager.hpp"
#include "core/memory/Hooks.hpp"
#include <bedrocktools/events/EventBus.hpp>
#include <bedrocktools/events/LocalPlayerTickEvent.hpp>
#include <bedrocktools/memory/Signatures.hpp>
#include <bedrocktools/sdk/Offsets.hpp>
#include <bedrocktools/sdk/network/Packet.hpp>
#include <bedrocktools/sdk/world/Actor.hpp>
#include <nlohmann/json.hpp>

#include <atomic>
#include <chrono>
#include <cstdarg>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <memory>
#include <mutex>
#include <new>
#include <string>
#include <sys/mman.h>
#include <unistd.h>
#include <vector>

namespace {
namespace sdk = bedrocktools::sdk;
using bedrocktools::memory::SignatureId;
using CreatePacketFn = std::shared_ptr<void> (*)(int);
using HandleFn = void (*)(void* dispatcher, void* netId, void* callback, std::shared_ptr<sdk::Packet>& packet);

constexpr int kAnimateEntityPacketId = 0x9E;
constexpr std::size_t kNetIdCopySize = 0x100;
constexpr std::size_t kPlayerScanSize = 0x1800;
constexpr std::size_t kPayloadScanSize = 0x140;
constexpr std::size_t kNpos = static_cast<std::size_t>(-1);
constexpr auto kExternalGrace = std::chrono::seconds(2);

// Nilai sama persis dengan yang dikirim EAF (PlayerAnimState.runPlayerAnimations).
constexpr const char* kMainAnimation = "animation.mbp_ap.player";
constexpr const char* kMainController = "controller.animation.mbp_ap.player.main";
constexpr const char* kMainStopExpression = "q.is_first_person || q.is_gliding || !q.is_alive";

// Tebakan awal layout payload AnimateEntityPacket (libc++ string = 24 byte).
// BELUM TERVERIFIKASI. Dipakai hanya setelah kalibrasi mencocokkannya dengan packet asli dari EAF.
struct Layout {
    std::size_t anim = 0x00;
    std::size_t next = 0x18;
    std::size_t stop = 0x30;
    std::size_t ver = 0x48;
    std::size_t ctrl = 0x50;
    std::size_t blend = 0x68;
    std::size_t ids = 0x70;
    bool verified = false;
};

CreatePacketFn gCreatePacket = nullptr;
HandleFn gStackOriginal = nullptr;
HandleFn gAnimOriginal = nullptr;

std::mutex gStateMutex;
Layout gLayout;
std::string gNextState = "default";
std::int32_t gMolangVersion = 0;
float gBlendOutTime = 0.f;
std::size_t gRuntimeIdOffset = 0;  // 0 = belum diketahui
std::vector<std::uint64_t> gPendingIds;

std::mutex gNetMutex;
unsigned char gNetIdCopy[kNetIdCopySize]{};
bool gHaveNetId = false;
std::atomic<void*> gCallback{nullptr};
std::atomic<std::int64_t> gLastExternalNs{0};
thread_local bool gSending = false;
std::atomic_bool gLoggedArmState{false};

std::filesystem::path dataDir() {
    std::filesystem::path p(bedrocktools::config::ConfigManager::get().getConfigPath());
    return p.has_parent_path() ? p.parent_path() : std::filesystem::path("/sdcard/games/MotionLevi");
}

void logf(const char* fmt, ...) {
    char line[1024];
    va_list args;
    va_start(args, fmt);
    std::vsnprintf(line, sizeof(line), fmt, args);
    va_end(args);
    try {
        std::filesystem::create_directories(dataDir());
        std::ofstream out(dataDir() / "motionlevi.log", std::ios::app);
        out << line << '\n';
    } catch (...) {
    }
}

std::int64_t nowNs() {
    return std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();
}

bool readable(const void* p, std::size_t n) {
    if (!p || n == 0) return false;
    const auto addr = reinterpret_cast<std::uintptr_t>(p);
    if (addr < 0x10000) return false;
    const std::size_t page = static_cast<std::size_t>(sysconf(_SC_PAGESIZE));
    const std::uintptr_t start = addr & ~(page - 1);
    const std::uintptr_t end = (addr + n + page - 1) & ~(page - 1);
    std::vector<unsigned char> vec((end - start) / page);
    return mincore(reinterpret_cast<void*>(start), end - start, vec.data()) == 0;
}

// Baca std::string libc++ mentah dengan aman. Coba layout alternatif Android dulu, lalu layout standar.
bool readStringAny(const unsigned char* p, std::string& out) {
    if (!readable(p, 24)) return false;
    // Layout alternatif (NDK): short -> byte[23] = size (<0x80), long -> byte[23] & 0x80
    const unsigned char last = p[23];
    if ((last & 0x80) == 0) {
        if (last >= 1 && last <= 22) {
            out.assign(reinterpret_cast<const char*>(p), last);
            return true;
        }
    } else {
        std::uint64_t size = 0;
        const char* data = nullptr;
        std::memcpy(&size, p + 8, 8);
        std::memcpy(&data, p, 8);
        if (size >= 1 && size <= 1024 && readable(data, static_cast<std::size_t>(size))) {
            out.assign(data, static_cast<std::size_t>(size));
            return true;
        }
    }
    // Layout standar: short -> byte[0] = size << 1 (LSB 0), long -> LSB 1, data di +16
    if ((p[0] & 1) == 0) {
        const std::size_t size = p[0] >> 1;
        if (size >= 1 && size <= 22) {
            out.assign(reinterpret_cast<const char*>(p + 1), size);
            return true;
        }
    } else {
        std::uint64_t size = 0;
        const char* data = nullptr;
        std::memcpy(&size, p + 8, 8);
        std::memcpy(&data, p + 16, 8);
        if (size >= 1 && size <= 1024 && readable(data, static_cast<std::size_t>(size))) {
            out.assign(data, static_cast<std::size_t>(size));
            return true;
        }
    }
    return false;
}

bool readIds(const unsigned char* p, std::vector<std::uint64_t>& out) {
    if (!readable(p, 24)) return false;
    std::uintptr_t begin = 0, end = 0;
    std::memcpy(&begin, p, 8);
    std::memcpy(&end, p + 8, 8);
    if (begin < 0x10000 || end <= begin) return false;
    const std::size_t bytes = end - begin;
    if (bytes % 8 != 0 || bytes > 64 * 8) return false;
    if (!readable(reinterpret_cast<const void*>(begin), bytes)) return false;
    out.resize(bytes / 8);
    std::memcpy(out.data(), reinterpret_cast<const void*>(begin), bytes);
    return true;
}

void setString(unsigned char* p, const std::string& value) {
    auto* s = reinterpret_cast<std::string*>(p);
    s->~basic_string();
    new (p) std::string(value);
}

void setIds(unsigned char* p, std::uint64_t id) {
    auto* v = reinterpret_cast<std::vector<std::uint64_t>*>(p);
    v->~vector();
    new (p) std::vector<std::uint64_t>{id};
}

std::string hexdump(const unsigned char* p, std::size_t n) {
    std::string out;
    char buf[8];
    for (std::size_t i = 0; i < n; ++i) {
        if (i % 16 == 0) {
            std::snprintf(buf, sizeof(buf), "\n%03zx:", i);
            out += buf;
        }
        std::snprintf(buf, sizeof(buf), " %02x", p[i]);
        out += buf;
    }
    return out;
}

void saveLearned() {
    try {
        nlohmann::json j;
        {
            std::lock_guard lock(gStateMutex);
            j["layout"] = {{"anim", gLayout.anim}, {"next", gLayout.next}, {"stop", gLayout.stop}, {"ver", gLayout.ver},
                           {"ctrl", gLayout.ctrl}, {"blend", gLayout.blend}, {"ids", gLayout.ids}, {"verified", gLayout.verified}};
            j["nextState"] = gNextState;
            j["molangVersion"] = gMolangVersion;
            j["blendOutTime"] = gBlendOutTime;
            j["runtimeIdOffset"] = gRuntimeIdOffset;
        }
        std::filesystem::create_directories(dataDir());
        std::ofstream(dataDir() / "learned.json") << j.dump(2);
    } catch (...) {
    }
}

void loadLearned() {
    try {
        std::ifstream in(dataDir() / "learned.json");
        if (!in) return;
        nlohmann::json j;
        in >> j;
        std::lock_guard lock(gStateMutex);
        if (j.contains("layout")) {
            const auto& l = j["layout"];
            gLayout.anim = l.value("anim", gLayout.anim);
            gLayout.next = l.value("next", gLayout.next);
            gLayout.stop = l.value("stop", gLayout.stop);
            gLayout.ver = l.value("ver", gLayout.ver);
            gLayout.ctrl = l.value("ctrl", gLayout.ctrl);
            gLayout.blend = l.value("blend", gLayout.blend);
            gLayout.ids = l.value("ids", gLayout.ids);
            gLayout.verified = l.value("verified", false);
        }
        gNextState = j.value("nextState", gNextState);
        gMolangVersion = j.value("molangVersion", gMolangVersion);
        gBlendOutTime = j.value("blendOutTime", gBlendOutTime);
        gRuntimeIdOffset = j.value("runtimeIdOffset", static_cast<std::size_t>(0));
    } catch (...) {
    }
}

// Pelajari layout dari packet asli yang dikirim EAF.
void learnFromPacket(const unsigned char* payload) {
    if (!readable(payload, kPayloadScanSize)) return;
    std::size_t anim = kNpos, ctrl = kNpos, stop = kNpos;
    std::string s;
    for (std::size_t off = 0; off + 24 <= kPayloadScanSize; off += 8) {
        if (!readStringAny(payload + off, s)) continue;
        if (anim == kNpos && s.rfind("animation.", 0) == 0) anim = off;
        else if (ctrl == kNpos && s.rfind("controller.", 0) == 0) ctrl = off;
        else if (stop == kNpos && s.find("is_first_person") != std::string::npos) stop = off;
    }
    if (anim == kNpos || ctrl == kNpos || stop == kNpos) {
        logf("[learn] gagal: string animation/controller/stop tidak ketemu. dump:%s", hexdump(payload, 0x90).c_str());
        return;
    }
    Layout learned;
    learned.anim = anim;
    learned.stop = stop;
    learned.ctrl = ctrl;
    learned.next = anim + 24;
    learned.ver = stop + 24;
    learned.blend = ctrl + 24;
    learned.ids = ctrl + 32;

    std::string next;
    const bool hasNext = readStringAny(payload + learned.next, next);
    std::int32_t version = 0;
    float blend = 0.f;
    std::memcpy(&version, payload + learned.ver, 4);
    std::memcpy(&blend, payload + learned.blend, 4);

    std::vector<std::uint64_t> ids;
    const bool hasIds = readIds(payload + learned.ids, ids);
    learned.verified = hasIds;

    {
        std::lock_guard lock(gStateMutex);
        const bool changed = std::memcmp(&learned, &gLayout, sizeof(std::size_t) * 7) != 0 || !gLayout.verified;
        gLayout = learned;
        if (hasNext) gNextState = next;
        gMolangVersion = version;
        gBlendOutTime = blend;
        if (hasIds) gPendingIds = ids;
        if (changed) logf("[learn] layout baru anim=%zx next=%zx stop=%zx ver=%zx ctrl=%zx blend=%zx ids=%zx nextState='%s' molang=%d blend=%.3f ids=%zu verified=%d",
                          learned.anim, learned.next, learned.stop, learned.ver, learned.ctrl, learned.blend, learned.ids,
                          gNextState.c_str(), version, blend, ids.size(), learned.verified ? 1 : 0);
    }
    if (hasIds) logf("[learn] runtime id dari packet asli: %llu", static_cast<unsigned long long>(ids.front()));
    saveLearned();
}

void captureNet(void* netId, void* callback) {
    if (!callback) return;
    {
        std::lock_guard lock(gNetMutex);
        if (netId && readable(netId, kNetIdCopySize)) {
            std::memcpy(gNetIdCopy, netId, kNetIdCopySize);
            gHaveNetId = true;
        }
    }
    gCallback.store(callback, std::memory_order_release);
}

void stackDetour(void* dispatcher, void* netId, void* callback, std::shared_ptr<sdk::Packet>& packet) {
    captureNet(netId, callback);
    if (gStackOriginal) gStackOriginal(dispatcher, netId, callback, packet);
}

void animDetour(void* dispatcher, void* netId, void* callback, std::shared_ptr<sdk::Packet>& packet) {
    if (!gSending) {
        captureNet(netId, callback);
        if (packet) {
            gLastExternalNs.store(nowNs(), std::memory_order_release);
            learnFromPacket(reinterpret_cast<const unsigned char*>(packet.get()) + sdk::offsets::Packet::Size);
        }
    }
    if (gAnimOriginal) gAnimOriginal(dispatcher, netId, callback, packet);
}

bool externalDriverActive() {
    const auto last = gLastExternalNs.load(std::memory_order_acquire);
    return last != 0 && nowNs() - last < std::chrono::duration_cast<std::chrono::nanoseconds>(kExternalGrace).count();
}

// Cari offset runtime id di objek Player berdasarkan id yang dipelajari dari packet asli.
void learnRuntimeIdOffset(sdk::Player* player) {
    std::vector<std::uint64_t> ids;
    {
        std::lock_guard lock(gStateMutex);
        if (gRuntimeIdOffset != 0 || gPendingIds.empty()) return;
        ids = gPendingIds;
    }
    if (!readable(player, kPlayerScanSize)) return;
    const auto* base = reinterpret_cast<const unsigned char*>(player);
    std::vector<std::size_t> candidates;
    for (const auto id : ids) {
        if (id == 0) continue;
        for (std::size_t off = 8; off + 8 <= kPlayerScanSize; off += 8) {
            std::uint64_t value = 0;
            std::memcpy(&value, base + off, 8);
            if (value == id) candidates.push_back(off);
        }
    }
    if (candidates.empty()) {
        logf("[learn] runtime id tidak ada di objek Player (kemungkinan disimpan di komponen ECS). Isi runtimeIdOffset manual atau kirim log.");
        std::lock_guard lock(gStateMutex);
        gPendingIds.clear();
        return;
    }
    if (candidates.size() > 1) {
        std::string list;
        char buf[16];
        for (std::size_t i = 0; i < candidates.size() && i < 16; ++i) {
            std::snprintf(buf, sizeof(buf), " %zx", candidates[i]);
            list += buf;
        }
        logf("[learn] kandidat offset runtime id ambigu (%zu):%s. Coba kalibrasi di server/dengan pemain lain (id lebih besar), atau isi manual.", candidates.size(), list.c_str());
        std::lock_guard lock(gStateMutex);
        gPendingIds.clear();
        return;
    }
    {
        std::lock_guard lock(gStateMutex);
        gRuntimeIdOffset = candidates.front();
        gPendingIds.clear();
    }
    logf("[learn] runtimeIdOffset = 0x%zx", candidates.front());
    saveLearned();
}

void sendMainAnimation(sdk::Player* player) {
    Layout layout;
    std::string nextState;
    std::int32_t molang;
    float blend;
    std::size_t idOffset;
    {
        std::lock_guard lock(gStateMutex);
        layout = gLayout;
        nextState = gNextState;
        molang = gMolangVersion;
        blend = gBlendOutTime;
        idOffset = gRuntimeIdOffset;
    }
    void* callback = gCallback.load(std::memory_order_acquire);

    if (!gLoggedArmState.exchange(true)) {
        logf("[state] layout.verified=%d runtimeIdOffset=0x%zx callback=%p createPacket=%p", layout.verified ? 1 : 0, idOffset, callback,
             reinterpret_cast<void*>(gCreatePacket));
    }
    if (!layout.verified || idOffset == 0 || !callback || !gCreatePacket) return;
    if (externalDriverActive()) return;  // EAF masih aktif, jangan dobel
    if (!readable(reinterpret_cast<const unsigned char*>(player) + idOffset, 8)) return;

    std::uint64_t runtimeId = 0;
    std::memcpy(&runtimeId, reinterpret_cast<const unsigned char*>(player) + idOffset, 8);
    if (runtimeId == 0) return;

    unsigned char netId[kNetIdCopySize];
    {
        std::lock_guard lock(gNetMutex);
        if (!gHaveNetId) return;
        std::memcpy(netId, gNetIdCopy, sizeof(netId));
    }

    std::shared_ptr<void> raw = gCreatePacket(kAnimateEntityPacketId);
    if (!raw) return;
    auto* base = reinterpret_cast<unsigned char*>(raw.get());
    auto* payload = base + sdk::offsets::Packet::Size;

    setString(payload + layout.anim, kMainAnimation);
    setString(payload + layout.next, nextState);
    setString(payload + layout.stop, kMainStopExpression);
    setString(payload + layout.ctrl, kMainController);
    std::memcpy(payload + layout.ver, &molang, sizeof(molang));
    std::memcpy(payload + layout.blend, &blend, sizeof(blend));
    setIds(payload + layout.ids, runtimeId);

    void* dispatcher = *reinterpret_cast<void**>(base + sdk::offsets::Packet::mHandlerDispatcher);
    if (!dispatcher) return;
    void** vtable = *reinterpret_cast<void***>(dispatcher);
    if (!vtable) return;
    auto handle = reinterpret_cast<HandleFn>(vtable[sdk::offsets::PacketHandlerDispatcher::HandlePacketVtableIndex]);
    if (!handle) return;

    std::shared_ptr<sdk::Packet> packet = std::static_pointer_cast<sdk::Packet>(raw);
    gSending = true;
    handle(dispatcher, netId, callback, packet);
    gSending = false;
}

void installDispatcherHook(int packetId, void* detour, void** original) {
    if (!gCreatePacket) return;
    std::shared_ptr<void> packet = gCreatePacket(packetId);
    if (!packet) return;
    auto* base = reinterpret_cast<unsigned char*>(packet.get());
    void* dispatcher = *reinterpret_cast<void**>(base + sdk::offsets::Packet::mHandlerDispatcher);
    if (!dispatcher) return;
    void** vtable = *reinterpret_cast<void***>(dispatcher);
    if (!vtable) return;
    void* target = vtable[sdk::offsets::PacketHandlerDispatcher::HandlePacketVtableIndex];
    if (target) bedrocktools::hooks::install(target, detour, original);
}
}  // namespace

MotionDriverModule::MotionDriverModule()
    : Module("Motion Driver", "Runs Motion+ third-person animations natively, replacing the EAF behavior pack.") {
    masterEnabled = true;
    enabled = true;
}

void MotionDriverModule::onInit() {
    loadLearned();
    gCreatePacket = reinterpret_cast<CreatePacketFn>(bedrocktools::memory::resolve(SignatureId::MinecraftPacketsCreatePacket));

    const auto stack = bedrocktools::memory::resolve(SignatureId::ResourcePackStackPacketHandle);
    if (stack) bedrocktools::hooks::install(reinterpret_cast<void*>(stack), reinterpret_cast<void*>(stackDetour), reinterpret_cast<void**>(&gStackOriginal));
    installDispatcherHook(kAnimateEntityPacketId, reinterpret_cast<void*>(animDetour), reinterpret_cast<void**>(&gAnimOriginal));

    logf("[init] createPacket=%p stackHook=%d animHook=%d", reinterpret_cast<void*>(gCreatePacket), stack ? 1 : 0, gAnimOriginal ? 1 : 0);

    bedrocktools::events::bus().subscribe<bedrocktools::events::LocalPlayerTickEvent>([this](auto& event) {
        if (!enabled || !event.player) return;
        try {
            learnRuntimeIdOffset(event.player);
            sendMainAnimation(event.player);
        } catch (...) {
            gSending = false;
        }
    });
}

void MotionDriverModule::onEnable() {
    gLoggedArmState.store(false);
}

void MotionDriverModule::onDisable() {}
