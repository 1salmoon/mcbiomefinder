#pragma once

#include "../Module.hpp"

// MotionDriver: pengganti script EAF (Entity Animation Framework) di sisi native.
//
// EAF cuma memanggil player.playAnimation(...) tiap tick, yang di balik layar
// mengirim AnimateEntityPacket (id 0x9E) ke client. Modul ini membuat packet yang
// sama secara lokal lalu menyuapkannya ke handler client, jadi Motion+ jalan tanpa
// behavior pack.
//
// Tiga hal yang belum bisa diverifikasi tanpa binary game, jadi dipelajari otomatis
// (mode kalibrasi) dan disimpan ke learned.json:
//   1. layout payload AnimateEntityPacket
//   2. offset ActorRuntimeID di objek Player lokal
//   3. nilai MolangVersion + nextState yang dipakai script API
class MotionDriverModule : public Module {
public:
    MotionDriverModule();
    void onInit() override;
    void onEnable() override;
    void onDisable() override;
};
